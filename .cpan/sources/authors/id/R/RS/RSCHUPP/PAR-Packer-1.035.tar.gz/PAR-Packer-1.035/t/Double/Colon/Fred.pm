package Double::Colon::Fred;
1;
